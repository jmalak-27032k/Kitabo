// The file contents for the current environment will overwrite these during build.
// The build system defaults to the dev environment which uses `environment.ts`, but if you do
// `ng build --env=prod` then `environment.prod.ts` will be used instead.
// The list of which env maps to which file can be found in `.angular-cli.json`.

export const environment = {
  production: false,
  //  firebaseConfig : {
  //   apiKey: "AIzaSyAEyOfwiXnpsVEHxJhIEuYk45wZiCaSH4E",
  //   authDomain: "library-manager-6b061.firebaseapp.com",
  //   databaseURL: "https://library-manager-6b061.firebaseio.com",
  //   projectId: "library-manager-6b061",
  //   storageBucket: "library-manager-6b061.appspot.com",
  //   messagingSenderId: "41393008634",
  //   appId: "1:41393008634:web:55a904aa2af22092997e43",
  //   measurementId: "G-L792PYVKJT"
  // }
};
