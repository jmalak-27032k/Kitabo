import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-my-oders',
  templateUrl: './my-oders.component.html',
  styleUrls: ['./my-oders.component.scss']
})
export class MyOdersComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
