import { MatngularPage } from './app.po';

describe('Matngular App', () => {
  let page: MatngularPage;

  beforeEach(() => {
    page = new MatngularPage();
  });

  it('should expect true to be true', () => {
    expect(true).toBe(true);
  });
});
